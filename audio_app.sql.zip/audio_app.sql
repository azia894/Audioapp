-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 26, 2021 at 09:31 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `audio_app`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `user_name` varchar(225) NOT NULL,
  `user_pass` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `user_name`, `user_pass`) VALUES
(1, 'admin', '123');

-- --------------------------------------------------------

--
-- Table structure for table `aud_author`
--

CREATE TABLE `aud_author` (
  `id` int(10) NOT NULL,
  `aut_name` varchar(225) NOT NULL,
  `aut_desc` text NOT NULL,
  `aut_img` varchar(225) NOT NULL,
  `dob` varchar(250) NOT NULL,
  `created_on` datetime NOT NULL,
  `aut_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aud_author`
--

INSERT INTO `aud_author` (`id`, `aut_name`, `aut_desc`, `aut_img`, `dob`, `created_on`, `aut_status`) VALUES
(1, 'Felix Weingartner ', '<p>asdfasdfasfdafdadsfasdfasdfasdfasdfasasdasd</p>', '1616437798.jpg', '1834-1995', '2021-03-15 20:35:33', 1),
(2, 'Apj Abdul Kalam', '<p>He played an important role in the second Pokhran nuclear test in 1998. He was also associated with India\'s space program and missile development program. Therefore, he is also called \"Missile Man\".</p>', '1615919478.jpg', '1983-2015', '2021-03-16 19:31:18', 1),
(3, 'Yasmin Mogahed', 'Yasmin Mogahed is a Muslim woman based in the US. She is a specialist in spirituality, psychology, and personal development. She completed her B.S. in psychology at the University of Wisconsin–Madison.', '', '', '2021-06-01 17:23:17', 1),
(4, 'furi', 'furi', 'https://firebasestorage.googleapis.com/v0/b/dilkiawaz-6854d.appspot.com/o/authorImages%2Ffuri.jpg?alt=media&token=c655e91d-188a-430d-b5c9-9673a3ba2a41', '', '2021-06-24 09:28:04', 1);

-- --------------------------------------------------------

--
-- Table structure for table `aud_booktbl`
--

CREATE TABLE `aud_booktbl` (
  `bkid` int(10) NOT NULL,
  `author_id` int(11) NOT NULL,
  `sub_id` int(11) NOT NULL,
  `bk_name` varchar(225) NOT NULL,
  `bk_desc` text NOT NULL,
  `bk_img` varchar(225) NOT NULL,
  `bk_age` varchar(250) NOT NULL,
  `bk_year` varchar(100) NOT NULL,
  `bk_tags` varchar(250) NOT NULL,
  `bk_blurb` varchar(150) NOT NULL,
  `bk_rating` int(11) NOT NULL,
  `ratingMemCount` int(11) NOT NULL DEFAULT 0,
  `bk_views` int(11) NOT NULL DEFAULT 0,
  `created_on` datetime NOT NULL,
  `bk_status` tinyint(1) NOT NULL,
  `bk_type` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aud_booktbl`
--

INSERT INTO `aud_booktbl` (`bkid`, `author_id`, `sub_id`, `bk_name`, `bk_desc`, `bk_img`, `bk_age`, `bk_year`, `bk_tags`, `bk_blurb`, `bk_rating`, `ratingMemCount`, `bk_views`, `created_on`, `bk_status`, `bk_type`) VALUES
(1, 2, 2, 'It', 't is a 1986 horror novel by American author Stephen King. It was his 22nd book and his 17th novel written under his own name. The story follows the experiences of seven children as they are terrorized by an evil entity that exploits the fears of its victims to disguise itself while hunting its prey. ', 'https://images-na.ssl-images-amazon.com/images/I/41h8tLeMLcL._SX322_BO1,204,203,200_.jpg', 'Adults', '1564-1616', 'asdasda,asdasdasd', 'asdasd asdasd', 7, 0, 4, '2021-03-16 19:28:15', 1, 1),
(3, 2, 2, 'Wings Of Fire', 'The New York Times bestselling Wings of Fire series soars to new heights in this first-ever graphic novel adaptation!Not every dragonet wants a destiny ... Clay has grown up under the mountain, chosen along with four other dragonets to fulfill a mysterious prophecy and end the war between the dragon tribes of Pyrrhia', 'https://images-na.ssl-images-amazon.com/images/I/91J05uyW1QL.jpg', '', '', '', '', 3, 0, 0, '2021-03-16 19:32:21', 1, 2),
(14, 3, 4, 'Reclaim Your Heart', 'Reclaim Your Heart is not just a self-help book. It is a manual about the journey of the heart in and out of the ocean of this life. It is a book about how to keep your heart from sinking to the depths of that ocean, and what to do when it does. It is a book about redemption, about hope, about renewal. Every heart can heal, and each moment is created to bring us closer to that transformative return. Reclaim Your Heart is about finding that moment when everything stops and suddenly looks different. It is about finding your own awakening. And then returning to the better, truer, and freer version of yourself. Many of us live our lives, entrapped by the same repeated patterns of heartbreak and disappointment. Many of us have no idea why this happens. Reclaim Your Heart is about freeing the heart from this slavery. It is about the journey in an out of life\'s most deceptive traps. This book was written to awaken the heart and provide a new perspective on love, loss, happiness, and pain. Providing a manual of sorts, Reclaim Your Heart will teach readers how to live in this life without allowing life to own you. It is a manual of how to protect your most prized possession: the heart.', 'https://firebasestorage.googleapis.com/v0/b/dilkiawaz-6854d.appspot.com/o/bookImages%2FReclaim%20Your%20Heart.jpg?alt=media&token=a1682599-4a99-40ba-b5e2-45d5416f0a66', 'Adults', '2012', 'religious', 'Reclaim Your Heart is not just a self-help book.', 0, 0, 0, '2021-06-01 17:33:46', 1, 0),
(33, 2, 0, 'newbook1', 'ww', 'https://firebasestorage.googleapis.com/v0/b/dilkiawaz-6854d.appspot.com/o/bookImages%2Fnewbook1.png?alt=media&token=267950a1-58d6-4027-a653-01e201c4aaa2', 'Adults', '2012', 'ww', 'ee', 0, 0, 0, '2021-06-19 16:59:15', 1, 0),
(34, 3, 0, 'ssssssss', 'sss', 'https://firebasestorage.googleapis.com/v0/b/dilkiawaz-6854d.appspot.com/o/bookImages%2Fssssssss.jpeg?alt=media&token=52f25647-9744-4314-a32a-f48a465b90ee', 'children', '2012', 'ww', 'ee', 0, 0, 0, '2021-06-24 09:07:30', 1, 0),
(35, 3, 0, 'aaaaaaa', 'aaa', 'https://firebasestorage.googleapis.com/v0/b/dilkiawaz-6854d.appspot.com/o/bookImages%2Faaaaaaa.jpg?alt=media&token=0661ecfc-5c92-4b90-ba87-0d7b9dcd4d34', 'children', '2012', 'sss', 'ee', 0, 0, 0, '2021-06-24 09:25:35', 1, 0),
(36, 4, 3, 'new new book', 'wwww', '', 'Adults', '1998', 'ww', 'ee', 0, 0, 0, '2021-06-26 09:29:16', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `aud_chapter`
--

CREATE TABLE `aud_chapter` (
  `id` int(10) NOT NULL,
  `bid` int(11) NOT NULL,
  `nar_id` int(11) NOT NULL,
  `ch_name` varchar(225) NOT NULL,
  `ch_audio` varchar(225) NOT NULL,
  `ch_duration` time NOT NULL,
  `created_on` datetime NOT NULL DEFAULT current_timestamp(),
  `count` int(11) NOT NULL,
  `ch_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aud_chapter`
--

INSERT INTO `aud_chapter` (`id`, `bid`, `nar_id`, `ch_name`, `ch_audio`, `ch_duration`, `created_on`, `count`, `ch_status`) VALUES
(17, 3, 5, 'new', 'https://firebasestorage.googleapis.com/v0/b/dilkiawaz-6854d.appspot.com/o/audio%2F3%2Fnew.mp3?alt=media&token=362a5686-2f94-4fb1-8741-dec8f2846cc7', '00:52:00', '2021-05-31 18:37:08', 0, 1),
(18, 6, 5, 'first chapter', 'https://firebasestorage.googleapis.com/v0/b/dilkiawaz-6854d.appspot.com/o/audio%2F6%2Ffirst%20chapter.mp3?alt=media&token=062b1a4c-ede9-4508-ae7d-a507311172e3', '03:37:00', '2021-06-01 07:21:23', 0, 1),
(19, 8, 5, 'newchapter', 'https://firebasestorage.googleapis.com/v0/b/dilkiawaz-6854d.appspot.com/o/audio%2F8%2Fnewchapter.mp3?alt=media&token=a3f84806-0dfd-412b-9ce0-a21b403a0604', '03:37:00', '2021-06-01 07:27:02', 0, 1),
(20, 1, 5, 'hello', 'https://firebasestorage.googleapis.com/v0/b/dilkiawaz-6854d.appspot.com/o/audio%2F1%2Fhello.mp3?alt=media&token=2da296e1-d17f-4195-acca-b9b68802de1a', '03:37:00', '2021-06-01 17:46:01', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `aud_narrator`
--

CREATE TABLE `aud_narrator` (
  `id` int(10) NOT NULL,
  `nar_name` varchar(225) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `nar_desc` text NOT NULL,
  `nar_img` varchar(225) NOT NULL,
  `created_on` datetime NOT NULL DEFAULT current_timestamp(),
  `nar_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aud_narrator`
--

INSERT INTO `aud_narrator` (`id`, `nar_name`, `gender`, `country`, `city`, `nar_desc`, `nar_img`, `created_on`, `nar_status`) VALUES
(1, 'bo yo', 'female', 'india', 'hyderabad', '<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\\\\\\\\\\\\\\\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. asdasdadsasdasd</p>', '1616438722.png', '2021-03-16 18:03:11', 1),
(2, 'ko yo', 'female', 'india', 'hyderabad', '<p>asdasdasdasdasdadsasdasdasdasd</p>', '', '2021-03-28 14:12:01', 1),
(3, 'yo yo', 'male', 'india', 'hyderabad', 'i\'m yoyo famous', '', '2021-04-14 16:57:41', 1),
(4, 'jo yo', 'male', 'india', 'hyderabad', 'i\'m yoyo famous', '', '2021-04-14 16:57:44', 1),
(5, 'furi', 'male', 'india', 'Hyderabd', '<p>hellooeee&nbsp;</p>', '', '2021-05-31 16:41:38', 1);

-- --------------------------------------------------------

--
-- Table structure for table `aud_review`
--

CREATE TABLE `aud_review` (
  `id` int(11) NOT NULL,
  `bid` varchar(150) NOT NULL,
  `user_name` varchar(250) NOT NULL,
  `review` text NOT NULL,
  `rating` int(11) NOT NULL DEFAULT 0,
  `created_on` date NOT NULL DEFAULT current_timestamp(),
  `status` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `aud_review`
--

INSERT INTO `aud_review` (`id`, `bid`, `user_name`, `review`, `rating`, `created_on`, `status`) VALUES
(2, '1', '1', 'orem Ipsum is simply dummy ', 4, '2021-03-23', '1'),
(3, '2', '1', 'this books is good', 3, '2021-04-14', '1'),
(4, '1', '2', 'book is good', 5, '2021-04-14', '1'),
(5, '1', '2', 'book is not good', 4, '2021-04-14', '1'),
(6, '1', 'Feroz', 'Great book', 4, '2021-04-15', '1'),
(7, '1', 'Feroz', 'Great book', 4, '2021-04-15', '1'),
(8, '1', 'Feroz', 'Good book', 3, '2021-05-11', '1'),
(9, '1', 'Feroz', 'Good book', 3, '2021-05-11', '1'),
(10, '1', 'Feroz', 'Good book', 3, '2021-05-11', '1'),
(11, '1', 'Feroz', 'Good book', 4, '2021-05-11', '1');

-- --------------------------------------------------------

--
-- Table structure for table `aud_subject`
--

CREATE TABLE `aud_subject` (
  `id` int(11) NOT NULL,
  `sub_name` varchar(225) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aud_subject`
--

INSERT INTO `aud_subject` (`id`, `sub_name`, `status`, `created_on`) VALUES
(1, 'Short stories', 1, '2021-03-28 14:34:04'),
(2, 'Novel', 1, '2021-03-28 14:34:38'),
(3, 'History', 1, '2021-03-28 14:34:51'),
(4, 'Religious', 1, '2021-03-28 14:35:01'),
(5, 'Non-fiction', 1, '2021-03-28 14:35:12'),
(6, 'Fiction', 1, '2021-03-28 14:35:23'),
(7, 'Adventure', 1, '2021-03-28 14:35:38'),
(8, 'Biography', 1, '2021-03-28 14:35:53'),
(9, 'Humour', 1, '2021-03-28 14:36:03'),
(10, 'Society', 1, '2021-03-28 14:36:15'),
(11, 'Politics', 1, '2021-03-28 14:36:27'),
(12, 'Philosophy', 1, '2021-03-28 14:36:37');

-- --------------------------------------------------------

--
-- Table structure for table `booksubjects`
--

CREATE TABLE `booksubjects` (
  `id` int(11) NOT NULL,
  `bkid` int(11) DEFAULT NULL,
  `sub_id` int(11) DEFAULT NULL,
  `status` enum('0','1') DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `booksubjects`
--

INSERT INTO `booksubjects` (`id`, `bkid`, `sub_id`, `status`, `createdAt`, `updatedAt`) VALUES
(33, 33, 2, '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(34, 33, 3, '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(35, 33, 8, '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(36, 34, 2, '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(37, 34, 3, '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(38, 34, 4, '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(39, 35, 1, '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(40, 35, 2, '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(41, 35, 3, '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(42, 35, 8, '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `uuid` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `emailId` varchar(255) DEFAULT NULL,
  `status` enum('0','1') DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `aud_author`
--
ALTER TABLE `aud_author`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `aud_booktbl`
--
ALTER TABLE `aud_booktbl`
  ADD PRIMARY KEY (`bkid`);

--
-- Indexes for table `aud_chapter`
--
ALTER TABLE `aud_chapter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `aud_narrator`
--
ALTER TABLE `aud_narrator`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `aud_review`
--
ALTER TABLE `aud_review`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `aud_subject`
--
ALTER TABLE `aud_subject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `booksubjects`
--
ALTER TABLE `booksubjects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `aud_author`
--
ALTER TABLE `aud_author`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `aud_booktbl`
--
ALTER TABLE `aud_booktbl`
  MODIFY `bkid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `aud_chapter`
--
ALTER TABLE `aud_chapter`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `aud_narrator`
--
ALTER TABLE `aud_narrator`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `aud_review`
--
ALTER TABLE `aud_review`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `aud_subject`
--
ALTER TABLE `aud_subject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `booksubjects`
--
ALTER TABLE `booksubjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
